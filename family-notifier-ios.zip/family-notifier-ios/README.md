# Family Notifier — iPhone app

The family's web app, wrapped as a real iPhone app: calls in the earpiece by
default (Speaker only when tapped), calls that ring like a phone call on the
lock screen through CallKit even when the app is closed, and calls that keep
going while you use another app.

It is the counterpart of the Android app (`notifier-main`): the same page,
the same bridges (`FamilyApp`, `FamilyAudio`, `FamilyUpdate`), the same
notifications, the same server — so `index.html` needs no change.

Built automatically by GitHub Actions and delivered through **TestFlight**
(Apple's internal-testing track). **Start with [SETUP.md](SETUP.md).**

    ios/                            the app (Swift, a WKWebView around APP_URL)
      project.yml                   describes the Xcode project (XcodeGen makes it)
      Config.xcconfig               APP_URL, APP_ID, TEAM_ID… (the workflow fills it)
      FamilyNotifier/
        MainViewController.swift    the page, permissions, links, files
        Bridge.swift                window.FamilyApp / FamilyAudio / FamilyUpdate for the page
        AudioRoute.swift            earpiece / speaker / headset routing
        CallManager.swift           CallKit: ringing on the lock screen, calls in the background
        PushCenter.swift            VoIP pushes (PushKit) and ordinary notifications
        Notes.swift, Shared/        the notifications, Arabic, message grouping
        Updater.swift               "a newer build is on TestFlight"
      FamilyNotifierNSE/            notification extension: dresses up the server's pushes
    server/family-server.js         the family server with Apple push (APNs) added
    site/.well-known/
      apple-app-site-association    makes the family's links open in the app
    .github/workflows/
      ios-build.yml                 builds, and uploads to TestFlight
      ios-make-csr.yml, ios-finish-cert.yml   only if Apple refuses cloud signing

## How the pieces map to the Android app

| Android (Kotlin)            | iPhone (Swift)                        |
|-----------------------------|---------------------------------------|
| `MainActivity` + WebView    | `MainViewController` + WKWebView      |
| `FamilyAppBridge`, `FamilyAudioBridge` (`@JavascriptInterface`) | `Bridge` (a small script defines the same objects; the app answers through `WKScriptMessageHandler`) |
| `PushService` (Firebase)    | `PushCenter` (PushKit VoIP + APNs)    |
| `Notes` (notification channels, full-screen intent) | `CallManager` (CallKit) for calls; `Notify` + the notification extension for the rest |
| `CallService` (foreground service, microphone) | the CallKit call itself (background modes audio/voip) |
| `FamilySounds` (ringtone, vibration) | CallKit rings; `Sounds.note()` for the notification sound |
| `Updater` (downloads an APK) | `Updater` (opens TestFlight)         |
| `assetlinks.json`           | `apple-app-site-association`          |
| Google Play internal testing| TestFlight                            |

## What is different on an iPhone, and why

- **Calls ring through CallKit.** iOS gives an app no other way to use the
  phone's ringtone, vibrate, respect the silent switch and Do Not Disturb, or
  show a call on the lock screen. So an incoming call is reported to CallKit
  (from a VoIP push when the app is closed; from the page when it is open),
  and Answer / Decline on that screen are passed back to the page. Calls are
  kept out of the Phone app's Recents.
- **Two push addresses, one token.** iOS wakes a closed app at once only
  for VoIP pushes, so calls go that way and everything else as ordinary
  notifications. The page sees a single token (`apns:…`) and registers it
  exactly as the Android app's Firebase token; the server tells them apart.
- **Updates come from TestFlight.** An app cannot install another app on
  iOS. The page's "Update" bar still appears when a newer build exists
  (`latest-ios.json`); Update opens TestFlight, where one tap installs it.
- **Saved files** go to Photos (pictures) or to Files → On My iPhone →
  Family Notifier, with the share sheet opened.
- **No share-into-the-app.** An iPhone app only receives shared text through
  a separate Share Extension, which is not included; the family's links open
  the app directly (universal links) and the page's "Paste my link" works.
