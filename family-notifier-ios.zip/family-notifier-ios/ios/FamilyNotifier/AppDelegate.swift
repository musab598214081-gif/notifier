import UIKit
import UserNotifications

@main
final class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Notes.setUp()
        UNUserNotificationCenter.current().delegate = self
        _ = CallManager.shared                     /* ready before the first VoIP push */
        PushCenter.shared.start()

        let w = UIWindow(frame: UIScreen.main.bounds)
        w.backgroundColor = MainViewController.night
        w.rootViewController = MainViewController()
        w.makeKeyAndVisible()
        window = w
        Store.foreground = true

        /* Opened from a notification or a link while closed. */
        if let n = launchOptions?[.remoteNotification] as? [AnyHashable: Any], let p = Shared.payload(from: n) {
            _ = PushCenter.shared.handleAlert(p, foreground: false)
        }
        return true
    }

    /* ------------------------------------------------ the family's links */

    /* Invitations and the links in notifications (https://<APP_HOST>/…) open
       in the app once the site's apple-app-site-association names it. */
    func application(_ application: UIApplication, continue userActivity: NSUserActivity,
                     restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
        guard userActivity.activityType == NSUserActivityTypeBrowsingWeb, let u = userActivity.webpageURL else { return false }
        MainViewController.shared?.open(u.absoluteString)
        return true
    }

    /* ------------------------------------------------ push addresses */

    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        Store.setApnsToken(PushCenter.hex(deviceToken))
        PushCenter.shared.tokensChanged()
    }
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {}

    /* A notification push reaching the app in the background (content-available). */
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any],
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        if let p = Shared.payload(from: userInfo) { _ = PushCenter.shared.handleAlert(p, foreground: Store.foreground) }
        completionHandler(.noData)
    }

    /* ------------------------------------------------ notifications */

    /* With the app on screen the page shows things itself, so nothing is
       shown - except the test notification, which exists to be seen. */
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent n: UNNotification,
                                withCompletionHandler done: @escaping (UNNotificationPresentationOptions) -> Void) {
        let info = n.request.content.userInfo
        let show: Bool
        if let p = Shared.payload(from: info) { show = PushCenter.shared.handleAlert(p, foreground: true) }
        else { show = (info["kind"] as? String) == "test" }
        if #available(iOS 14.0, *) { done(show ? [.banner, .list, .sound] : []) } else { done(show ? [.alert, .sound] : []) }
    }

    /* Tapped, or one of its buttons. */
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive r: UNNotificationResponse,
                                withCompletionHandler done: @escaping () -> Void) {
        let info = r.notification.request.content.userInfo
        let kind = (info["kind"] as? String) ?? ""
        let p = Shared.payload(from: info) ?? [:]
        switch r.actionIdentifier {
        case Notify.actReject:
            if let s = info["rej"] as? String, let d = s.data(using: .utf8),
               let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] { Net.postPrepared(j) }
            Notes.remove(id: r.notification.request.identifier)
        case Notify.actApprove:
            if let u = info["approve"] as? String { MainViewController.shared?.open(u, kind: kind) }
        case Notify.actSend:
            if let u = info["send"] as? String { MainViewController.shared?.open(u, kind: kind) }
        case Notify.actCallBack:
            if let u = info["callback"] as? String { MainViewController.shared?.open(u, kind: kind) }
        case UNNotificationDismissActionIdentifier:
            break
        default:
            if kind == "msg", let from = p.str("from") { Shared.clearMessageLines(tag: "m-" + from) }
            if let u = info["open"] as? String { MainViewController.shared?.open(u, tag: p.str("tag"), kind: kind) }
        }
        done()
    }
}
