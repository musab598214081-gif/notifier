import AVFoundation
import UIKit

/**
 * window.FamilyAudio: real earpiece / loudspeaker routing for calls, which
 * a web page cannot do by itself. The page asks for a route (see
 * nativeAudio() in index.html):
 *
 *   "earpiece"  every call starts here - private, like the phone's dialler
 *   "speaker"   only when the person taps Speaker
 *   "off"       the call is over: the phone goes back to normal
 *
 * It answers with where the sound now goes ("earpiece", "speaker",
 * "headset", "bluetooth") and tells the page by itself when that changes
 * (headphones plugged in or out) through window.familyAudioRoute.
 *
 * The audio session itself is owned by CallKit (CallManager): a call is
 * reported to it so iOS keeps the microphone open in the background and
 * shows the call like a phone call; this class only chooses the output.
 */
final class AudioRoute {
    static let shared = AudioRoute()
    private let session = AVAudioSession.sharedInstance()
    private(set) var wanted = "off"
    private var active = false        /* CallKit has activated the session */

    private init() {
        NotificationCenter.default.addObserver(self, selector: #selector(routeChanged(_:)),
                                               name: AVAudioSession.routeChangeNotification, object: nil)
    }

    /** From the page. Answers where the sound goes now. */
    @discardableResult
    func setRoute(_ route: String) -> String {
        let was = wanted
        wanted = (route == "speaker" || route == "earpiece") ? route : "off"
        let where_ = apply()
        if (was == "off") != (wanted == "off") { CallManager.shared.pageAudio(active: wanted != "off") }
        return where_
    }

    /** CallKit activated the session for a call (the only time iOS lets a
        VoIP app's audio run freely in the background). */
    func sessionActivated() { active = true; _ = apply() ; tell() }
    func sessionDeactivated() { active = false }

    func configureForCall() {
        do {
            try session.setCategory(.playAndRecord, mode: .voiceChat,
                                    options: [.allowBluetooth, .allowBluetoothA2DP])
        } catch {}
    }

    /** The current output, in the page's words. */
    func current() -> String {
        for o in session.currentRoute.outputs {
            switch o.portType {
            case .headphones, .usbAudio, .lineOut: return "headset"
            case .bluetoothHFP, .bluetoothA2DP, .bluetoothLE, .carAudio: return "bluetooth"
            case .builtInSpeaker: return "speaker"
            case .builtInReceiver: return "earpiece"
            default: continue
            }
        }
        return ""
    }

    private func apply() -> String {
        if wanted == "off" {
            proximity(false)
            /* CallKit deactivates the session when the call ends; without a
               CallKit call (nothing was ringing) it is let go here. */
            if !CallManager.shared.hasAnyCall { try? session.setActive(false, options: .notifyOthersOnDeactivation) }
            return ""
        }
        configureForCall()
        if !active { try? session.setActive(true) }
        let loud = wanted == "speaker"
        let now = current()
        /* Headphones always win in Phone mode, as in a phone call; Speaker
           is the loudspeaker whatever is plugged in (as on Android). */
        if loud {
            if now != "speaker" { try? session.overrideOutputAudioPort(.speaker) }
        } else {
            if now == "speaker" { try? session.overrideOutputAudioPort(.none) }
        }
        let where_ = current()
        proximity(where_ == "earpiece")
        return where_
    }

    /* Something changed underneath - headphones in or out, Bluetooth, or
       the page's own media re-routing: the chosen mode is put back and the
       page told. */
    @objc private func routeChanged(_ n: Notification) {
        guard wanted != "off" else { return }
        DispatchQueue.main.async { _ = self.apply(); self.tell() }
    }
    private func tell() {
        guard wanted != "off" else { return }
        let w = current()
        Bridge.set("route", w)
        Bridge.js("window.familyAudioRoute && window.familyAudioRoute(\(jsQuote(w)))")
    }

    /* The screen goes dark while the phone is held to the ear, as in the dialler. */
    private func proximity(_ on: Bool) {
        DispatchQueue.main.async { UIDevice.current.isProximityMonitoringEnabled = on }
    }
}
