import Foundation
import WebKit

/**
 * What the page sees: window.FamilyApp, window.FamilyAudio and
 * window.FamilyUpdate, the same objects the Android WebView provides (see
 * "inside the family's Android app" in index.html), so the page needs no
 * iPhone-specific code.
 *
 * A WKWebView cannot answer a page's call synchronously, so a small script
 * defines those objects in JavaScript: each method posts to the app, and
 * the few that must answer at once (pushToken, notifState, setRoute, ring)
 * answer from a state the app keeps up to date through Bridge.set.
 */
enum Bridge {
    static let appHandler = "familyApp", audioHandler = "familyAudio", updateHandler = "familyUpdate"

    static let script = """
    (function(){
      if (window.FamilyApp) return;
      var S = { token: "", notif: "default", route: "", ring: "ok", note: "ok" };
      function post(h, m){ try { window.webkit.messageHandlers[h].postMessage(m); } catch (e) {} }
      window.FamilyApp = {
        helper: function(json){ post("familyApp", { f: "helper", json: String(json) }); },
        pushToken: function(){ return S.token; },
        notifState: function(){ return S.notif; },
        askNotify: function(){ post("familyApp", { f: "askNotify" }); },
        saveFile: function(name, mime, b64){ post("familyApp", { f: "saveFile", name: String(name), mime: String(mime), b64: String(b64) }); return "ok"; },
        ring: function(on, tag){ post("familyApp", { f: "ring", on: !!on, tag: String(tag || "") }); return on ? S.ring : "ok"; },
        note: function(){ post("familyApp", { f: "note" }); return S.note; },
        openSoundSettings: function(){ post("familyApp", { f: "openSoundSettings" }); }
      };
      window.FamilyAudio = {
        setRoute: function(r){ post("familyAudio", { route: String(r) }); return r === "off" ? "" : S.route; }
      };
      window.FamilyUpdate = {
        version: function(){ return "\(Config.versionName)"; },
        versionCode: function(){ return \(Config.buildNumber); },
        check: function(){ post("familyUpdate", { f: "check" }); },
        install: function(){ post("familyUpdate", { f: "install" }); }
      };
      window.__familySet = function(k, v){ S[k] = v; };
    })();
    """

    /** Runs a line of JavaScript in the page, if the app is open. */
    static func js(_ code: String) {
        DispatchQueue.main.async { MainViewController.shared?.web.evaluateJavaScript(code, completionHandler: nil) }
    }
    /** Brings one of the values the page reads synchronously up to date. */
    static func set(_ key: String, _ value: String) {
        js("window.__familySet && __familySet(\(jsQuote(key)), \(jsQuote(value)))")
    }

    /** What the page tells the app (the same things it tells sw.js). */
    static func helper(_ json: String, host: MainViewController) {
        guard let data = json.data(using: .utf8),
              let m = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        switch m.str("t") {
        case "cfg":
            var c = m; c.removeValue(forKey: "t"); Store.setCfg(c)
        case "lang":
            Store.setLang(m.str("v") ?? "en")
            Notes.setUp()                       /* the buttons' words follow the language */
        case "silence":
            if let tag = m.str("tag") { Store.silence(tag); CallManager.shared.pageSilenced(tag: tag) }
        case "audible":
            if let tag = m.str("tag") { Store.audible(tag, m.bool("on")) }
        case "forget":
            Store.forget()
        case "readchat":
            if let from = m.str("from") { Notes.clearChat(from: from) }
        case "test":
            Notes.other(["title": m.str("title") ?? "Family Notifier", "body": m.str("body") ?? "", "tag": "fmn-test"], kind: "test")
        default: break
        }
    }
}
