import CallKit
import AVFoundation
import UIKit

/**
 * Calls as the phone shows its own: through CallKit.
 *
 *  - An incoming call (a VoIP push, or the page ringing while open) is
 *    reported to CallKit, which rings with the phone's ringtone at its
 *    ring volume, vibrates, honours the silent switch and Do Not Disturb,
 *    and fills the screen - also when the phone is locked or the app is
 *    closed. Answer and Decline on that screen come back here.
 *  - A call the page is on (incoming answered, or outgoing) is a CallKit
 *    call too, so iOS keeps the microphone and the sound going while you
 *    use another app or lock the phone (the job CallService does on
 *    Android).
 *
 * Every VoIP push must report a call to CallKit, so a push that turns out
 * to be nothing to ring for (cancelled, silenced, stale) reports one and
 * ends it at once; with includesCallsInRecents off, nothing is left behind.
 */
final class CallManager: NSObject, CXProviderDelegate {
    static let shared = CallManager()

    struct Info {
        let uuid: UUID
        let tag: String
        var kind: String
        var who: String
        var url: String
        var answer: String
        var dec: [String: Any]?
        var answered = false
        var outgoing = false
        var byPage = false         /* answered in the page, not on CallKit's screen */
    }

    private let provider: CXProvider
    private let controller = CXCallController()
    private var calls: [UUID: Info] = [:]
    private var timeouts: [UUID: DispatchWorkItem] = [:]
    private var grace: DispatchWorkItem?

    var hasAnyCall: Bool { !calls.isEmpty }

    private override init() {
        let cfg = CXProviderConfiguration()
        cfg.supportsVideo = false
        cfg.maximumCallGroups = 1
        cfg.maximumCallsPerCallGroup = 1
        cfg.supportedHandleTypes = [.generic]
        cfg.includesCallsInRecents = false
        if let img = UIImage(named: "CallKitIcon") { cfg.iconTemplateImageData = img.pngData() }
        provider = CXProvider(configuration: cfg)
        super.init()
        provider.setDelegate(self, queue: nil)
    }

    private func find(tag: String) -> Info? { calls.values.first { $0.tag == tag } }
    func isRinging(tag: String) -> Bool { find(tag: tag).map { !$0.answered } ?? false }
    func has(tag: String) -> Bool { find(tag: tag) != nil }

    /* ------------------------------------------------------- incoming */

    /** A ringing call. If this tag already rings, only its name is brought up to date. */
    func reportIncoming(tag: String, kind: String, who: String, url: String, answer: String,
                        dec: [String: Any]?, completion: @escaping () -> Void) {
        if var c = find(tag: tag) {
            if c.who != who && !who.isEmpty {
                c.who = who; c.url = url; c.answer = answer; c.dec = dec ?? c.dec
                calls[c.uuid] = c
                let up = CXCallUpdate(); up.localizedCallerName = who
                up.remoteHandle = CXHandle(type: .generic, value: who)
                provider.reportCall(with: c.uuid, updated: up)
            }
            completion(); return
        }
        let uuid = UUID()
        let up = CXCallUpdate()
        up.remoteHandle = CXHandle(type: .generic, value: who)
        up.localizedCallerName = who
        up.hasVideo = false
        up.supportsGrouping = false
        up.supportsUngrouping = false
        up.supportsHolding = false
        up.supportsDTMF = false
        calls[uuid] = Info(uuid: uuid, tag: tag, kind: kind, who: who, url: url, answer: answer, dec: dec)
        provider.reportNewIncomingCall(with: uuid, update: up) { err in
            if err != nil { self.calls.removeValue(forKey: uuid) }
            else {
                /* Rings as long as the server does (RING_FOR + a little), then stops. */
                let w = DispatchWorkItem { self.end(uuid: uuid, reason: .unanswered) }
                self.timeouts[uuid] = w
                DispatchQueue.main.asyncAfter(deadline: .now() + 65, execute: w)
            }
            completion()
        }
    }

    /** A VoIP push with nothing to ring for: reported and ended at once (see above). */
    func reportPhantom(completion: @escaping () -> Void) {
        let uuid = UUID()
        let up = CXCallUpdate()
        up.remoteHandle = CXHandle(type: .generic, value: "Family Notifier")
        up.localizedCallerName = "Family Notifier"
        provider.reportNewIncomingCall(with: uuid, update: up) { _ in
            self.provider.reportCall(with: uuid, endedAt: Date(), reason: .failed)
            completion()
        }
    }

    func end(tag: String, reason: CXCallEndedReason) {
        guard let c = find(tag: tag) else { return }
        end(uuid: c.uuid, reason: reason)
    }
    private func end(uuid: UUID, reason: CXCallEndedReason) {
        guard calls[uuid] != nil else { return }
        timeouts[uuid]?.cancel(); timeouts.removeValue(forKey: uuid)
        calls.removeValue(forKey: uuid)
        provider.reportCall(with: uuid, endedAt: Date(), reason: reason)
        if calls.isEmpty { AudioRoute.shared.setRoute("off") }
    }
    func endAll(reason: CXCallEndedReason) { for u in Array(calls.keys) { end(uuid: u, reason: reason) } }

    /* --------------------------------------------- from the page (Bridge) */

    /** FamilyApp.ring(on, tag): the page shows an incoming call and wants the
        phone to ring. On iOS that is a CallKit call (the only way to the
        ringtone); the push for the same call usually reported it already. */
    func pageRing(on: Bool, tag tag0: String) {
        let tag = tag0.isEmpty ? "preview" : tag0
        grace?.cancel(); grace = nil
        if on {
            if has(tag: tag) { return }
            let who = tag == "preview" ? "Family Notifier" : (Store.lang() == "ar" ? "مكالمة واردة" : "Incoming call")
            reportIncoming(tag: tag, kind: "call", who: who, url: Config.appURL, answer: Config.appURL, dec: nil) {}
        } else {
            guard let c = find(tag: tag), !c.answered else { return }
            /* Stopped ringing: picked up here (a route request follows in a
               moment), declined here (a "silence" follows), or gone. A short
               grace tells which. */
            let w = DispatchWorkItem { [weak self] in
                guard let s = self, let c2 = s.find(tag: tag), !c2.answered else { return }
                s.end(uuid: c2.uuid, reason: .remoteEnded)
            }
            grace = w
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: w)
        }
    }

    /** The page answered, declined or ended a call itself. */
    func pageSilenced(tag: String) {
        guard let c = find(tag: tag), !c.answered else { return }
        end(uuid: c.uuid, reason: .declinedElsewhere)
    }

    /** FamilyAudio.setRoute: the page's call has sound now (on) or is over (off). */
    func pageAudio(active: Bool) {
        if active {
            grace?.cancel(); grace = nil
            if let ringing = calls.values.first(where: { !$0.answered }) {
                /* Picked up in the page: CallKit is told, so its screen agrees. */
                calls[ringing.uuid]?.byPage = true
                controller.request(CXTransaction(action: CXAnswerCallAction(call: ringing.uuid))) { _ in }
            } else if calls.isEmpty {
                /* An outgoing call (or a group call joined): a CallKit call
                   so it keeps going in the background. */
                let uuid = UUID()
                let handle = CXHandle(type: .generic, value: Store.lang() == "ar" ? "مكالمة عائلية" : "Family call")
                calls[uuid] = Info(uuid: uuid, tag: "out:" + uuid.uuidString, kind: "out", who: handle.value,
                                   url: Config.appURL, answer: Config.appURL, dec: nil, answered: true, outgoing: true)
                let a = CXStartCallAction(call: uuid, handle: handle)
                controller.request(CXTransaction(action: a)) { err in
                    if err != nil { self.calls.removeValue(forKey: uuid) }
                }
            }
        } else {
            for c in calls.values where c.answered { end(uuid: c.uuid, reason: .remoteEnded) }
        }
    }

    /* ----------------------------------------------- CXProviderDelegate */

    func providerDidReset(_ provider: CXProvider) {
        calls.removeAll(); timeouts.values.forEach { $0.cancel() }; timeouts.removeAll()
        AudioRoute.shared.setRoute("off")
    }

    func provider(_ provider: CXProvider, perform action: CXStartCallAction) {
        AudioRoute.shared.configureForCall()
        provider.reportOutgoingCall(with: action.callUUID, startedConnectingAt: Date())
        provider.reportOutgoingCall(with: action.callUUID, connectedAt: Date())
        action.fulfill()
    }

    func provider(_ provider: CXProvider, perform action: CXAnswerCallAction) {
        guard var c = calls[action.callUUID] else { action.fail(); return }
        timeouts[c.uuid]?.cancel(); timeouts.removeValue(forKey: c.uuid)
        c.answered = true
        calls[c.uuid] = c
        AudioRoute.shared.configureForCall()
        /* Picked up: the ringing stops here, on the server, and on this
           person's other phones. */
        Store.silence(c.tag)
        Net.ringStop(c.tag)
        if !c.byPage {
            /* Answered on the phone's call screen: the page picks the call
               up (its #ans=… link, as a tapped Answer does on Android). */
            let tag = c.tag, answer = c.answer
            DispatchQueue.main.async {
                MainViewController.shared?.open(answer, tag: tag, kind: c.kind, how: "answer")
            }
        }
        action.fulfill()
    }

    func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
        guard let c = calls[action.callUUID] else { action.fail(); return }
        timeouts[c.uuid]?.cancel(); timeouts.removeValue(forKey: c.uuid)
        calls.removeValue(forKey: c.uuid)
        if !c.answered {
            /* Declined on the phone's screen: the request the page prepared
               goes to the server, as the notification's Decline does on Android. */
            Store.silence(c.tag)
            Net.ringStop(c.tag)
            Net.postPrepared(c.dec)
            Bridge.js("window.familyDeclined && familyDeclined(\(jsQuote(c.tag)))")
        } else {
            /* Hung up on the phone's screen (or in Control Centre): the page ends its call. */
            Bridge.js("(function(){ try { if (window.group && group.state === 'live') groupLeave(); " +
                      "else if (typeof hangUp === 'function') hangUp('ended'); } catch (e) {} })()")
        }
        if calls.isEmpty { AudioRoute.shared.setRoute("off") }
        action.fulfill()
    }

    func provider(_ provider: CXProvider, perform action: CXSetMutedCallAction) {
        Bridge.js("window.familyMute && familyMute(\(action.isMuted))")
        action.fulfill()
    }
    func provider(_ provider: CXProvider, perform action: CXSetHeldCallAction) { action.fail() }

    func provider(_ provider: CXProvider, didActivate audioSession: AVAudioSession) { AudioRoute.shared.sessionActivated() }
    func provider(_ provider: CXProvider, didDeactivate audioSession: AVAudioSession) { AudioRoute.shared.sessionDeactivated() }
}
