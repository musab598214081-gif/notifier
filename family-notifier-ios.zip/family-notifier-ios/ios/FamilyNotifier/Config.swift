import Foundation

/** Build-time settings (Config.xcconfig → Info.plist). */
enum Config {
    private static func s(_ k: String) -> String { (Bundle.main.object(forInfoDictionaryKey: k) as? String) ?? "" }
    /** Where index.html is hosted, e.g. https://yourname.github.io/family/ */
    static let appURL: String = {
        let u = s("FamilyAppURL").trimmingCharacters(in: .whitespaces)
        return u.isEmpty ? "https://example.com/" : u
    }()
    static let appHost: String = URL(string: appURL)?.host ?? "example.com"
    /** …/latest-ios.json; empty: the app never checks for updates. */
    static let updateURL: String = {
        let u = s("FamilyUpdateURL").trimmingCharacters(in: .whitespaces)
        return u == "://" || u.hasPrefix("://") ? "" : u
    }()
    static let versionName: String = s("CFBundleShortVersionString")
    static let buildNumber: Int = Int(s("CFBundleVersion")) ?? 1
    static let bundleId: String = Bundle.main.bundleIdentifier ?? "app.family.notifyer"
}
