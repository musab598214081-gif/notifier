import Foundation
import Photos
import UIKit

/** A picture or file from a chat, saved (the WebView can't save blob: links):
    a picture goes to Photos, anything else to Files → On My iPhone → Family
    Notifier, and the share sheet opens so it can go anywhere else. */
enum Files {
    static func save(name: String, mime: String, b64: String, from vc: UIViewController) {
        guard let bytes = Data(base64Encoded: b64, options: .ignoreUnknownCharacters) else { return }
        let safe = name.replacingOccurrences(of: "[\\\\/:*?\"<>|]", with: "_", options: .regularExpression)
        let file = safe.isEmpty ? "file" : safe
        if mime.hasPrefix("image/"), let img = UIImage(data: bytes) {
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { st in
                guard st == .authorized || st == .limited else { return }
                PHPhotoLibrary.shared().performChanges({
                    PHAssetChangeRequest.creationRequestForAsset(from: img)
                }, completionHandler: nil)
            }
            return
        }
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let url = dir.appendingPathComponent(file)
        do { try bytes.write(to: url, options: .atomic) } catch { return }
        DispatchQueue.main.async {
            let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            share.popoverPresentationController?.sourceView = vc.view
            share.popoverPresentationController?.sourceRect = CGRect(x: vc.view.bounds.midX, y: vc.view.bounds.midY, width: 1, height: 1)
            vc.present(share, animated: true)
        }
    }
}
