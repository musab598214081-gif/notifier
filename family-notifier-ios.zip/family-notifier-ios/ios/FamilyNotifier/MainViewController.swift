import AVFoundation
import UIKit
import UserNotifications
import WebKit

/**
 * The family's web app (APP_URL) in a WKWebView, with what a browser can't
 * do: the earpiece (AudioRoute), calls that ring like a phone call even
 * when the app is closed (PushCenter + CallManager), and a call that keeps
 * going in the background (CallKit).
 */
final class MainViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    static let night = UIColor(red: 0x0F / 255, green: 0x1B / 255, blue: 0x2A / 255, alpha: 1)
    private(set) static weak var shared: MainViewController?

    private(set) var web: WKWebView!
    private let updater = Updater()
    private var pageReady = false
    private var pendingURL: String?
    private var recheckPush = false

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        MainViewController.shared = self
        view.backgroundColor = MainViewController.night

        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []       /* a call's sound starts by itself */
        cfg.allowsPictureInPictureMediaPlayback = false
        cfg.applicationNameForUserAgent = "FamilyNotifierApp/\(Config.versionName)"
        cfg.websiteDataStore = .default()
        if #available(iOS 14.0, *) {
            cfg.limitsNavigationsToAppBoundDomains = true        /* the bridges reach only the family's own address */
            cfg.defaultWebpagePreferences.allowsContentJavaScript = true
        }
        let ucc = WKUserContentController()
        ucc.addUserScript(WKUserScript(source: Bridge.script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucc.add(self, name: Bridge.appHandler)
        ucc.add(self, name: Bridge.audioHandler)
        ucc.add(self, name: Bridge.updateHandler)
        cfg.userContentController = ucc

        web = WKWebView(frame: .zero, configuration: cfg)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        web.isOpaque = false
        web.backgroundColor = MainViewController.night
        web.scrollView.backgroundColor = MainViewController.night
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(web)
        /* Clear of the notch, the home indicator and the keyboard. */
        NSLayoutConstraint.activate([
            web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.keyboardLayoutGuide.topAnchor),
            web.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
        ])

        if let u = pendingURL, allowed(u) { pendingURL = nil; web.load(URLRequest(url: URL(string: u)!)) }
        else if let u = URL(string: Config.appURL) { web.load(URLRequest(url: u)) }
        firstRun()
        pushNotifState()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(toFront), name: UIApplication.didBecomeActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(toBack), name: UIApplication.willResignActiveNotification, object: nil)
    }
    @objc private func toFront() {
        Store.foreground = true
        pushNotifState()
        if recheckPush { recheckPush = false; Bridge.js("window.familyPushToken && familyPushToken()") }
    }
    @objc private func toBack() { Store.foreground = false }

    /* ---------------------------------------------------------------- the page */

    /** Only the family app's own address opens inside the app (it can reach the bridges). */
    private func allowed(_ u: URL) -> Bool { u.scheme == "https" && u.host == Config.appHost }
    private func allowed(_ s: String) -> Bool { URL(string: s).map(allowed) ?? false }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let u = action.request.url else { decisionHandler(.cancel); return }
        if action.targetFrame?.isMainFrame == false { decisionHandler(.allow); return }
        if allowed(u) || u.scheme == "about" || u.scheme == "blob" { decisionHandler(.allow); return }
        /* Maps, web links and the like: in the phone's own apps. */
        UIApplication.shared.open(u)
        decisionHandler(.cancel)
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { pageReady = false }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        pageReady = true
        /* The values the page reads synchronously, in place from the first line. */
        Bridge.set("token", PushCenter.token())
        pushNotifState()
        Bridge.set("route", AudioRoute.shared.current())
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { webView.reload() }

    /* A link in a new window (target=_blank): the same page. */
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let u = action.request.url { if allowed(u) { webView.load(action.request) } else { UIApplication.shared.open(u) } }
        return nil
    }

    /* The page's alert / confirm / prompt, as the phone's own. */
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(a, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: NSLocalizedString("cancel", comment: ""), style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(a, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let a = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        a.addTextField { $0.text = defaultText }
        a.addAction(UIAlertAction(title: NSLocalizedString("cancel", comment: ""), style: .cancel) { _ in completionHandler(nil) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(a.textFields?.first?.text) })
        present(a, animated: true)
    }

    /* The microphone and the camera, for the family's own address only;
       iOS asks the person the first time. */
    @available(iOS 15.0, *)
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo,
                 type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(origin.host == Config.appHost ? .grant : .deny)
    }

    /* ---------------------------------------------------------------- the bridges */

    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let m = message.body as? [String: Any] else { return }
        switch message.name {
        case Bridge.audioHandler:
            AudioRoute.shared.setRoute(m.str("route") ?? "off")
        case Bridge.updateHandler:
            if m.str("f") == "check" { updater.check() } else if m.str("f") == "install" { updater.install() }
        case Bridge.appHandler:
            switch m.str("f") {
            case "helper": Bridge.helper(m.str("json") ?? "{}", host: self)
            case "askNotify": askNotify()
            case "saveFile": Files.save(name: m.str("name") ?? "file", mime: m.str("mime") ?? "", b64: m.str("b64") ?? "", from: self)
            case "ring": CallManager.shared.pageRing(on: m.bool("on"), tag: m.str("tag") ?? "")
            case "note": Sounds.note()
            case "openSoundSettings": Sounds.openSettings()
            default: break
            }
        default: break
        }
    }

    /** A notification tapped, a call answered, or a link opened into the app. */
    func open(_ url: String, tag: String? = nil, kind: String? = nil, how: String = "open") {
        if let tag = tag, kind == "call" || kind == "group", how != "full" {
            /* Picked up (or opened): the ringing stops here, on the server,
               and on this person's other phones. */
            Store.silence(tag)
            Net.ringStop(tag)
        }
        guard allowed(url) else { return }
        if !isViewLoaded { pendingURL = url; return }
        if !pageReady { web.load(URLRequest(url: URL(string: url)!)) }
        else { web.evaluateJavaScript("window.familyOpen && familyOpen(\(jsQuote(url)))", completionHandler: nil) }
    }

    /* ---------------------------------------------------------------- notifications */

    /** The first time: the microphone and notifications. */
    private func firstRun() {
        if Store.flag("askedStart") { return }
        Store.setFlag("askedStart")
        Store.setFlag("askedNotify")
        AVAudioSession.sharedInstance().requestRecordPermission { _ in
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in
                DispatchQueue.main.async {
                    self.pushNotifState()
                    Bridge.js("window.familyPushToken && familyPushToken()")
                }
            }
        }
    }

    /** "granted" | "denied" | "default", kept in the page's cached state. */
    func pushNotifState(_ then: ((String) -> Void)? = nil) {
        UNUserNotificationCenter.current().getNotificationSettings { s in
            let v: String
            switch s.authorizationStatus {
            case .authorized, .provisional, .ephemeral: v = "granted"
            case .denied: v = "denied"
            default: v = Store.flag("askedNotify") ? "denied" : "default"
            }
            Bridge.set("notif", v)
            if let f = then { DispatchQueue.main.async { f(v) } }
        }
    }

    /** The page's "turn on notifications" button. */
    private func askNotify() {
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings { s in
            switch s.authorizationStatus {
            case .authorized, .provisional, .ephemeral:
                Bridge.set("notif", "granted")
                Bridge.js("window.familyNotifyResult && familyNotifyResult(true)")
            case .notDetermined:
                Store.setFlag("askedNotify")
                center.requestAuthorization(options: [.alert, .sound, .badge]) { ok, _ in
                    self.pushNotifState { _ in Bridge.js("window.familyNotifyResult && familyNotifyResult(\(ok))") }
                }
            default:
                /* Refused before: only the phone's settings can turn them on now. */
                DispatchQueue.main.async { self.recheckPush = true; Sounds.openSettings() }
            }
        }
    }
}
