import Foundation

/** The few things the app says to the family server by itself. */
enum Net {
    static func post(_ url: String, _ body: String, done: ((Bool) -> Void)? = nil) {
        guard url.hasPrefix("https://"), let u = URL(string: url) else { done?(false); return }
        var r = URLRequest(url: u, timeoutInterval: 8)
        r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        r.httpBody = body.data(using: .utf8)
        URLSession.shared.dataTask(with: r) { _, resp, _ in
            let ok = (resp as? HTTPURLResponse).map { (200..<300).contains($0.statusCode) } ?? false
            done?(ok)
        }.resume()
    }

    private static func asMe() -> [String: Any]? {
        guard let cfg = Store.cfg(), let me = cfg.str("me") else { return nil }
        var b: [String: Any] = ["me": me]
        if let sec = cfg.str("sec") { b["sec"] = sec }
        return b
    }

    /** Picked up here: the server stops the repeat rings, and this person's other phones go quiet. */
    static func ringStop(_ tag: String) {
        guard let send = Store.cfg()?.str("send"), var b = asMe() else { return }
        b["k"] = "ringstop"; b["tag"] = tag
        post(send, jsonString(b))
    }

    /** A new push address while the app is closed: registered from here, as sw.js does. */
    static func sendSub(_ token: String) {
        guard !token.isEmpty, let send = Store.cfg()?.str("send"), var b = asMe() else { return }
        b["k"] = "sub"; b["sub"] = ["fcm": token]
        post(send, jsonString(b))
    }

    /** A request the page prepared ({u, b}): Decline a call, Reject a join request. */
    static func postPrepared(_ j: [String: Any]?) {
        guard let j = j, let u = j.str("u") else { return }
        post(u, jsonString(j.obj("b") ?? [:]))
    }
}
