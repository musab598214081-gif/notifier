import Foundation
import UserNotifications

/** The notifications the app makes itself (the server's alert pushes are
    decorated by the extension with the same code, in Notify). */
enum Notes {
    static func setUp() {
        UNUserNotificationCenter.current().setNotificationCategories(Notify.categories())
    }

    static func post(_ d: [String: Any], kind: String) {
        let c = UNMutableNotificationContent()
        let id = Notify.decorate(c, d, kind: kind, appURL: Config.appURL)
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings { s in
            guard s.authorizationStatus == .authorized || s.authorizationStatus == .provisional else { return }
            center.add(UNNotificationRequest(identifier: id, content: c, trigger: nil))
        }
    }

    static func missed(_ d: [String: Any]) { post(d, kind: "missed") }
    static func message(_ d: [String: Any]) { post(d, kind: "msg") }
    static func other(_ d: [String: Any], kind: String) { post(d, kind: kind) }

    /** The conversation was opened in the app: its notification has done its job. */
    static func clearChat(from: String) {
        let tag = "m-" + from
        Shared.clearMessageLines(tag: tag)
        remove(id: "n:" + tag)
    }
    static func cancelOther(tag: String) { remove(id: tag) }
    static func remove(id: String) {
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [id])
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [id])
    }
}
