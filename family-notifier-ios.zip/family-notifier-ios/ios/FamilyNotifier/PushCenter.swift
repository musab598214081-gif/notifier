import Foundation
import PushKit
import UIKit
import UserNotifications

/**
 * Pushes from the family server, through Apple's push service.
 *
 * Two addresses are registered with the server as one token
 * ("apns:<env>:<device token>:<voip token>", see token()): the server sends
 * calls to the VoIP one (PushKit wakes the app at once, even closed, and
 * the call is reported to CallKit here) and everything else - messages,
 * missed calls, buzzes, join requests - as ordinary notifications, which
 * the notification extension dresses up. The payload is the same JSON a
 * browser's sw.js receives, in the field "p".
 */
final class PushCenter: NSObject, PKPushRegistryDelegate {
    static let shared = PushCenter()
    private var registry: PKPushRegistry?
    private static let CALLING = try! NSRegularExpression(pattern: "\\s+is calling you.*$", options: .caseInsensitive)

    func start() {
        let r = PKPushRegistry(queue: .main)
        r.delegate = self
        r.desiredPushTypes = [.voIP]
        registry = r
        UIApplication.shared.registerForRemoteNotifications()
    }

    /** The one token the page registers with the server (empty until both halves are known). */
    static func token() -> String {
        let a = Store.apnsToken(), v = Store.voipToken()
        if a.isEmpty || v.isEmpty { return "" }
        #if DEBUG
        let env = "dev"
        #else
        let env = "prod"
        #endif
        return "apns:\(env):\(a):\(v)"
    }

    /** One half changed (iOS renews them now and then): the server and the page are told. */
    func tokensChanged() {
        let t = PushCenter.token()
        Bridge.set("token", t)
        if t.isEmpty { return }
        Net.sendSub(t)
        Bridge.js("window.familyPushToken && familyPushToken()")
    }

    static func hex(_ d: Data) -> String { d.map { String(format: "%02x", $0) }.joined() }

    /* ------------------------------------------------------- PushKit */

    func pushRegistry(_ registry: PKPushRegistry, didUpdate credentials: PKPushCredentials, for type: PKPushType) {
        Store.setVoipToken(PushCenter.hex(credentials.token))
        tokensChanged()
    }
    func pushRegistry(_ registry: PKPushRegistry, didInvalidatePushTokenFor type: PKPushType) {
        Store.setVoipToken("")
        Bridge.set("token", "")
    }
    func pushRegistry(_ registry: PKPushRegistry, didReceiveIncomingPushWith payload: PKPushPayload,
                      for type: PKPushType, completion: @escaping () -> Void) {
        guard let d = Shared.payload(from: payload.dictionaryPayload) else {
            CallManager.shared.reportPhantom(completion: completion); return
        }
        handleVoip(d, completion: completion)
    }

    /** A call-related push (call, group, cancel, missed): the decisions of Notes.handle on Android. */
    func handleVoip(_ d0: [String: Any], completion: @escaping () -> Void) {
        var d = d0
        var kind = d.str("kind") ?? "buzz"
        let tag = d.str("tag")
        let front = Store.foreground
        let cm = CallManager.shared

        /* An open page reconnects at once, so the call behind the push arrives now. */
        Bridge.js("window.familyPush && familyPush()")

        if kind == "cancel" {
            if let t = tag { Store.silence(t) }
            if let t = tag, cm.has(tag: t) { cm.end(tag: t, reason: .remoteEnded); completion() }
            else { cm.reportPhantom(completion: completion) }
            return
        }
        if kind == "missed" {
            if let t = tag { Store.silence(t) }
            let had = tag.map { cm.has(tag: $0) } ?? false
            if let t = tag, had { cm.end(tag: t, reason: .unanswered) }
            if !front { Notes.missed(d) }
            if had { completion() } else { cm.reportPhantom(completion: completion) }
            return
        }
        let ringing = kind == "call" || kind == "group"
        if ringing, let t = tag {
            /* A call that arrives long after it was sent is not ringing any more -
               measured by the server's clock (skew: how far this phone's is off). */
            let skew = Store.cfg()?.int64("skew") ?? 0
            let ts = d.int64("ts")
            let now = Int64(Date().timeIntervalSince1970 * 1000)
            if ts > 0 && abs(skew) < 86_400_000 && now + skew - ts > 70_000 {
                let who = PushCenter.CALLING.stringByReplacingMatches(in: d0.str("title") ?? "", range: NSRange(location: 0, length: (d0.str("title") ?? "").utf16.count), withTemplate: "")
                d["title"] = "Missed call"; d["body"] = who + " tried to call you"
                if let f = d0.str("from") { d["cb"] = f } else { d["cb"] = NSNull() }
                kind = "missed"
                Store.silence(t)
                if !front { Notes.missed(d) }
                cm.reportPhantom(completion: completion); return
            }
            if Store.isSilenced(t) { cm.reportPhantom(completion: completion); return }
            let url = d.str("url") ?? Notify.base(Config.appURL)
            let answer = d.str("answer") ?? d.str("ans").map { url + $0 } ?? url
            let title = d.str("title") ?? ""
            var who = PushCenter.CALLING.stringByReplacingMatches(in: title, range: NSRange(location: 0, length: title.utf16.count), withTemplate: "")
            if who.trimmingCharacters(in: .whitespaces).isEmpty { who = "Family Notifier" }
            cm.reportIncoming(tag: t, kind: kind, who: who, url: url, answer: answer, dec: d.obj("dec"), completion: completion)
            return
        }
        /* Not a call at all (should come as a notification, not through PushKit). */
        if !front || kind == "test" { Notes.other(d, kind: kind) }
        cm.reportPhantom(completion: completion)
    }

    /* ---------------------------------------- ordinary notifications */

    /** A notification push reached the app while it runs (willPresent, or a
        background wake). Answers whether iOS should show it: with the app on
        screen the page shows things itself (except the test one). */
    func handleAlert(_ d: [String: Any], foreground: Bool) -> Bool {
        let kind = d.str("kind") ?? "buzz"
        Bridge.js("window.familyPush && familyPush()")
        if kind == "cancel" || kind == "missed", let t = d.str("tag") {
            Store.silence(t)
            CallManager.shared.end(tag: t, reason: kind == "cancel" ? .remoteEnded : .unanswered)
        }
        if kind == "cancel" { return false }
        if foreground { return kind == "test" }
        return true
    }
}
