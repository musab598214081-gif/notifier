import Foundation
import UserNotifications

/**
 * How a push from the family server becomes a notification - the same
 * decisions sw.js makes for the browser and Notes.kt makes on Android.
 * Used by the app (for notifications it makes itself) and by the
 * notification extension (for the ones the server sends as alerts), so
 * both look the same.
 *
 *  - a message groups per sender: the last few lines in one notification;
 *  - a missed call offers Call back;
 *  - a join request offers Approve / Reject and stays until decided;
 *  - a renewed-invitation request offers Send link.
 *
 * Where to go on a tap, and what each button does, is written into
 * userInfo so the app can act on it (AppDelegate.didReceive).
 */
enum Notify {
    static let catMissed = "fmn.missed", catApprove = "fmn.approve", catRenew = "fmn.renew",
               catMessage = "fmn.message", catOther = "fmn.other"
    static let actCallBack = "callback", actApprove = "approve", actReject = "reject", actSend = "send"

    static func categories() -> Set<UNNotificationCategory> {
        let fg: UNNotificationActionOptions = [.foreground]
        let missed = UNNotificationCategory(identifier: catMissed, actions: [
            UNNotificationAction(identifier: actCallBack, title: Shared.act("Call back"), options: fg)], intentIdentifiers: [])
        let approve = UNNotificationCategory(identifier: catApprove, actions: [
            UNNotificationAction(identifier: actApprove, title: Shared.act("Approve"), options: fg),
            UNNotificationAction(identifier: actReject, title: Shared.act("Reject"), options: [.destructive])], intentIdentifiers: [])
        let renew = UNNotificationCategory(identifier: catRenew, actions: [
            UNNotificationAction(identifier: actSend, title: Shared.act("Send link"), options: fg)], intentIdentifiers: [])
        let message = UNNotificationCategory(identifier: catMessage, actions: [], intentIdentifiers: [])
        let other = UNNotificationCategory(identifier: catOther, actions: [], intentIdentifiers: [])
        return [missed, approve, renew, message, other]
    }

    /** The page's address (what the page told the app, else the build's). */
    static func base(_ fallback: String) -> String {
        if let s = Shared.defaults.string(forKey: "cfg"), let data = s.data(using: .utf8),
           let j = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let u = j.str("url") { return u }
        return fallback
    }
    static func enc(_ s: String) -> String {
        s.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? s
    }
    private static func frag(_ url: String, _ kv: String) -> String { url + (url.contains("#") ? "&" : "#") + kv }
    private static func page(_ url: String) -> String { url.components(separatedBy: "#").first ?? url }

    /** Fills c in for payload d; answers the notification's identifier (one per
        sender / call / request, so a repeat replaces rather than adds). */
    @discardableResult
    static func decorate(_ c: UNMutableNotificationContent, _ d: [String: Any], kind kind0: String, appURL: String) -> String {
        let kind = kind0
        let home = base(appURL)
        var url = d.str("url") ?? home
        var info: [String: Any] = ["p": jsonString(d), "kind": kind]
        c.sound = .default
        if #available(iOS 15.0, *) { c.interruptionLevel = kind == "missed" ? .active : .timeSensitive }
        var id: String

        switch kind {
        case "msg":
            let from = d.str("from") ?? ""
            let tag = d.str("tag") ?? "m-" + from
            if !from.isEmpty { url = frag(url, "chat=" + enc(from)) }
            let lines = Shared.addMessageLine(tag: tag, line: d.str("body") ?? "")
            c.title = Shared.tr(d.str("title") ?? "New message")
            c.body = lines.map(Shared.tr).joined(separator: "\n")
            c.categoryIdentifier = catMessage
            c.threadIdentifier = "n:" + tag
            c.badge = NSNumber(value: lines.count)
            id = "n:" + tag
        case "missed":
            let tag = d.str("tag") ?? d.str("from") ?? "x"
            if let cb = d.str("cb") { url = frag(url, "cb=" + enc(cb)) }
            c.title = Shared.tr(d.str("title") ?? "Missed call")
            c.body = Shared.tr(d.str("body") ?? "")
            c.categoryIdentifier = d.str("cb") != nil ? catMissed : catOther
            c.threadIdentifier = "missed"
            info["callback"] = url
            id = "x:" + tag
        default:
            /* A buzz, a test, a join request - one short alert. */
            let tag = d.str("tag") ?? kind
            c.title = Shared.tr(d.str("title") ?? "Family Notifier")
            c.body = Shared.tr(d.str("body") ?? "")
            c.categoryIdentifier = catOther
            c.threadIdentifier = "o:" + kind
            if kind == "approve", let jr = d.str("jr") {
                /* Somebody wants to join: stays until the admin decides. */
                url = page(home) + "#jr=" + enc(jr)
                info["approve"] = page(home) + "#approve=" + enc(jr)
                if let rej = d.obj("rej") { info["rej"] = jsonString(rej) }
                c.categoryIdentifier = catApprove
            }
            /* Somebody's invitation expired and they asked for a new link. */
            if kind == "renew", let rn = d.str("rn") {
                url = page(home) + "#renew=" + enc(rn)
                info["send"] = page(home) + "#renewsend=" + enc(rn)
                c.categoryIdentifier = catRenew
            }
            id = "o:" + tag
        }
        info["open"] = url
        c.userInfo = info
        return id
    }
}
