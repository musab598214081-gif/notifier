import Foundation

/* Code used by both the app and its notification extension: where the
   family's things are kept (an app group both can read), and the Arabic
   translations of what the server sends (the same list as sw.js and the
   Android app's Notes.kt). */

enum Shared {
    /** The app group both processes share; from Info.plist (FamilyAppGroup). */
    static var groupId: String {
        (Bundle.main.object(forInfoDictionaryKey: "FamilyAppGroup") as? String)
            ?? "group." + (Bundle.main.bundleIdentifier ?? "app.family.notifyer").replacingOccurrences(of: ".nse", with: "")
    }
    static var defaults: UserDefaults { UserDefaults(suiteName: groupId) ?? .standard }

    static func lang() -> String { defaults.string(forKey: "lang") == "ar" ? "ar" : "en" }

    /* ------------------------------------------------ Arabic, as in sw.js */

    private static let AR_NOTE: [(NSRegularExpression, String)] = [
        ("^(.+?) is calling you.*$", "$1 يتصل بك"),
        ("^(.+?) is buzzing you$", "$1 ينبّهك"),
        ("^(.+?) tried to call you$", "$1 حاول الاتصال بك"),
        ("^(.+?) is asking you into a group call$", "$1 يدعوك إلى مكالمة جماعية"),
        ("^(.+?) wants to join$", "$1 يريد الانضمام"),
        ("^Missed call$", "مكالمة فائتة"),
        ("^Missed group call$", "مكالمة جماعية فائتة"),
        ("^Group call$", "مكالمة جماعية"),
        ("^New message$", "رسالة جديدة"),
        ("^Incoming call$", "مكالمة واردة"),
        ("^Call ended$", "انتهت المكالمة"),
        ("^Tap to answer$", "اضغط للرد"),
        ("^wants your attention$", "يريد انتباهك"),
        ("^\u{1F4F7} Photo", "\u{1F4F7} صورة"),
        ("^\u{1F4CD} Location", "\u{1F4CD} الموقع"),
        ("^\u{1F3A4} Voice message", "\u{1F3A4} رسالة صوتية"),
        ("^Call me$", "اتصل بي"),
        ("^Come here please$", "تعال هنا من فضلك"),
        ("^Dinner is ready$", "العشاء جاهز"),
        ("^Are you OK\\?$", "هل أنت بخير؟"),
        ("^I'm on my way$", "أنا في الطريق"),
        ("^Ring me when free$", "اتصل بي عندما تتفرغ"),
        ("^This is how messages and other notifications look and sound\\.$", "هكذا تبدو الرسائل والإشعارات الأخرى وتُسمع.")
    ].compactMap { pair -> (NSRegularExpression, String)? in
        guard let re = try? NSRegularExpression(pattern: pair.0) else { return nil }
        return (re, pair.1)
    }

    static let AR_ACT: [String: String] = ["Call back": "معاودة الاتصال", "Approve": "موافقة",
                                           "Reject": "رفض", "Send link": "إرسال الرابط"]

    /** A notification's text in the family's language. */
    static func tr(_ text: String) -> String {
        if lang() != "ar" { return text }
        return text.split(separator: "\n", omittingEmptySubsequences: false).map { lineSub -> String in
            let line = String(lineSub)
            let range = NSRange(line.startIndex..., in: line)
            for (re, rep) in AR_NOTE where re.firstMatch(in: line, range: range) != nil {
                return re.stringByReplacingMatches(in: line, range: range, withTemplate: rep)
            }
            return line
        }.joined(separator: "\n")
    }
    static func act(_ label: String) -> String { lang() == "ar" ? (AR_ACT[label] ?? label) : label }

    /** The last few lines of one sender's messages, one notification per sender (as Notes.kt). */
    static func addMessageLine(tag: String, line: String) -> [String] {
        var all = defaults.dictionary(forKey: "msgLines") as? [String: [String]] ?? [:]
        var lines = all[tag] ?? []
        lines.append(line)
        while lines.count > 4 { lines.removeFirst() }
        all[tag] = lines
        defaults.set(all, forKey: "msgLines")
        return lines
    }
    static func clearMessageLines(tag: String) {
        var all = defaults.dictionary(forKey: "msgLines") as? [String: [String]] ?? [:]
        all.removeValue(forKey: tag)
        defaults.set(all, forKey: "msgLines")
    }

    /** The push payload (the JSON a browser's sw.js receives) out of a notification's userInfo. */
    static func payload(from userInfo: [AnyHashable: Any]) -> [String: Any]? {
        if let s = userInfo["p"] as? String, let d = s.data(using: .utf8),
           let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] { return j }
        if let j = userInfo["p"] as? [String: Any] { return j }
        return nil
    }
}

extension Dictionary where Key == String, Value == Any {
    /** A string field, or nil when it is missing, empty or JSON null (as JSONObject.str in Store.kt). */
    func str(_ k: String) -> String? {
        guard let v = self[k] else { return nil }
        if v is NSNull { return nil }
        if let s = v as? String { return s.isEmpty ? nil : s }
        if let n = v as? NSNumber { return n.stringValue }
        return nil
    }
    func int64(_ k: String, _ def: Int64 = 0) -> Int64 {
        if let n = self[k] as? NSNumber { return n.int64Value }
        if let s = self[k] as? String, let n = Int64(s) { return n }
        return def
    }
    func bool(_ k: String) -> Bool { (self[k] as? Bool) ?? ((self[k] as? NSNumber)?.boolValue ?? false) }
    func obj(_ k: String) -> [String: Any]? { self[k] as? [String: Any] }
}

func jsonString(_ o: Any) -> String {
    (try? JSONSerialization.data(withJSONObject: o)).flatMap { String(data: $0, encoding: .utf8) } ?? "{}"
}
/** A JavaScript string literal of s (as JSONObject.quote). */
func jsQuote(_ s: String) -> String { jsonString([s]).dropFirst().dropLast().description }
