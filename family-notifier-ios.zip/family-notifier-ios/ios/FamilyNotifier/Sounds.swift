import AudioToolbox
import UIKit

/** The phone's own sounds, for the page while the app is on screen. A
    ringing call is CallKit's job (CallManager.pageRing); what is left is the
    notification sound, once - an alert sound follows the silent switch and
    the phone's volume, as a notification would. */
enum Sounds {
    static func note() {
        AudioServicesPlayAlertSoundWithCompletion(SystemSoundID(1007), nil)
    }
    /** The phone's notification settings for this app. */
    static func openSettings() {
        var s: String = UIApplication.openSettingsURLString
        if #available(iOS 15.4, *) { s = UIApplication.openNotificationSettingsURLString }
        if let u = URL(string: s) { UIApplication.shared.open(u) }
    }
}
