import Foundation

/** What the page has told the app (the same things it tells sw.js), kept
    between launches - in the app group, so the notification extension can
    read the language and the message lines too. */
enum Store {
    private static var d: UserDefaults { Shared.defaults }

    /** The app is on screen right now. */
    static var foreground = false

    /** Calls the open page is ringing out loud for: no second ring on top of it. */
    static var audible = Set<String>()
    private static let lock = NSLock()
    static func audible(_ tag: String, _ on: Bool) { lock.lock(); if on { audible.insert(tag) } else { audible.remove(tag) }; lock.unlock() }
    static func isAudible(_ tag: String) -> Bool { lock.lock(); defer { lock.unlock() }; return audible.contains(tag) }

    /** { send, me, sec, skew, url } - where the family server is and who this phone is. */
    static func cfg() -> [String: Any]? {
        guard let s = d.string(forKey: "cfg"), let data = s.data(using: .utf8) else { return nil }
        return try? JSONSerialization.jsonObject(with: data) as? [String: Any]
    }
    static func setCfg(_ j: [String: Any]) { d.set(jsonString(j), forKey: "cfg") }
    static func forget() { d.removeObject(forKey: "cfg") }

    static func lang() -> String { Shared.lang() }
    static func setLang(_ v: String) { d.set(v == "ar" ? "ar" : "en", forKey: "lang") }

    /* The two push addresses: the ordinary one (messages, alerts) and the
       VoIP one (calls, through PushKit). The page sees them as one
       token - see PushCenter.token(). */
    static func apnsToken() -> String { d.string(forKey: "apns") ?? "" }
    static func setApnsToken(_ t: String) { d.set(t, forKey: "apns") }
    static func voipToken() -> String { d.string(forKey: "voip") ?? "" }
    static func setVoipToken(_ t: String) { d.set(t, forKey: "voip") }

    static func flag(_ name: String) -> Bool { d.bool(forKey: "flag." + name) }
    static func setFlag(_ name: String) { d.set(true, forKey: "flag." + name) }

    /** Calls answered, declined or ended here: their later rings stay quiet (as sw.js does). */
    static func silence(_ tag: String) {
        lock.lock(); defer { lock.unlock() }
        var o = d.dictionary(forKey: "silenced") as? [String: Double] ?? [:]
        let now = Date().timeIntervalSince1970 * 1000
        o[tag] = now
        o = o.filter { now - $0.value <= 15 * 60_000 }
        d.set(o, forKey: "silenced")
    }
    static func isSilenced(_ tag: String) -> Bool {
        lock.lock(); defer { lock.unlock() }
        let o = d.dictionary(forKey: "silenced") as? [String: Double] ?? [:]
        guard let t = o[tag] else { return false }
        return Date().timeIntervalSince1970 * 1000 - t < 15 * 60_000
    }
}
