import Foundation
import UIKit

/* In-app updates.
 *
 * On an iPhone the app itself only ever arrives through TestFlight (or the
 * App Store), which installs new versions by itself. So this answers the
 * page's FamilyUpdate.check() by reading the small file the workflow
 * publishes with every build (UPDATE_URL, latest-ios.json: the newest build
 * number, its name, what it brings, and the TestFlight link); if that build
 * is newer than this one, the page shows its "Update" bar, and install()
 * opens TestFlight, where one tap installs it. Results go to the page
 * through window.familyUpdate({...}), as on Android. */
final class Updater {
    private var latest: [String: Any]?

    private func say(_ state: String, _ extra: [String: Any] = [:]) {
        var o: [String: Any] = ["state": state, "current": Config.buildNumber, "currentName": Config.versionName]
        if let l = latest {
            o["code"] = l["build"] ?? l["versionCode"] ?? 0
            o["name"] = l["versionName"] ?? ""; o["notes"] = l["notes"] ?? ""
        }
        extra.forEach { o[$0.key] = $0.value }
        Bridge.js("window.familyUpdate && familyUpdate(\(jsQuote(jsonString(o))))")
    }

    func check() {
        let base = Config.updateURL
        guard !base.isEmpty, let u = URL(string: base + (base.contains("?") ? "&" : "?") + "t=\(Int(Date().timeIntervalSince1970))") else {
            say("none"); return
        }
        var r = URLRequest(url: u, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 10)
        r.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        URLSession.shared.dataTask(with: r) { data, _, _ in
            guard let data = data, let j = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                self.say("checkfailed"); return
            }
            let code = Int((j["build"] as? NSNumber)?.intValue ?? (j["versionCode"] as? NSNumber)?.intValue ?? 0)
            let url = (j["url"] as? String) ?? ""
            if code > Config.buildNumber && url.hasPrefix("https://") { self.latest = j; self.say("available") }
            else { self.latest = nil; self.say("none") }
        }.resume()
    }

    func install() {
        guard let j = latest, let s = j["url"] as? String, let u = URL(string: s) else { say("failed", ["why": "nocheck"]); return }
        say("installing")
        DispatchQueue.main.async { UIApplication.shared.open(u) }
    }
}
