import UserNotifications

/**
 * Dresses up the notifications the family server sends as alerts (messages,
 * missed calls, buzzes, join requests): the family's language, one
 * notification per sender with the last few lines, the right buttons - the
 * same as the app's own notifications, through Notify.
 *
 * Calls never come this way: they arrive as VoIP pushes and ring through
 * CallKit (see PushCenter in the app).
 */
final class NotificationService: UNNotificationServiceExtension {
    private var handler: ((UNNotificationContent) -> Void)?
    private var content: UNMutableNotificationContent?

    override func didReceive(_ request: UNNotificationRequest, withContentHandler contentHandler: @escaping (UNNotificationContent) -> Void) {
        handler = contentHandler
        let c = (request.content.mutableCopy() as? UNMutableNotificationContent) ?? UNMutableNotificationContent()
        content = c
        if let d = Shared.payload(from: request.content.userInfo) {
            let kind = d.str("kind") ?? "buzz"
            /* The page's address: what the server put in the push, else what
               the app has saved; the build's own address is not known here. */
            let home = Notify.base(d.str("url") ?? "")
            Notify.decorate(c, d, kind: kind, appURL: home)
            c.userInfo["p"] = request.content.userInfo["p"]        /* as sent */
        }
        contentHandler(c)
    }

    override func serviceExtensionTimeWillExpire() {
        if let h = handler, let c = content { h(c) }
    }
}
