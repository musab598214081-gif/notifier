# Changes to family-server.js for the iPhone app

Everything already there is untouched; four things are added.

1. `features` now lists `"apns"` when the four `APNS_*` secrets are set
   (the way `"fcm"` reports the Firebase secret).
2. `subscribe()` accepts the iPhone app's token in the same place as the
   Android app's: `sub.fcm = "apns:<prod|dev>:<device token>:<voip token>"`.
   It is kept as `{ apns: { env, dev, voip } }` under the same `sub:` keys,
   hashed as `"fcm:" + token`, so `unsub` from the page works unchanged.
3. `pushTo()` routes such a registration to the new `apnsSend()`:
   - `call`, `group`, `cancel`, `missed` → a **VoIP push** (PushKit) with the
     payload in `p`; the ring loop's repeat rings (`n > 0`) are not sent,
     CallKit keeps ringing by itself;
   - everything else → an **alert** push (`mutable-content`, `content-available`,
     collapse id per sender / request, time-sensitive) with the payload in `p`
     for the notification extension.
   `apnsJwt()` signs the request with the APNs key (ES256), cached 50 minutes.
   410 / BadDeviceToken answer as 404 so the registration is forgotten, as for
   Firebase.
4. `/app/latest-ios.json` serves the iPhone build's update file from the
   repository's fixed `ios-latest` release (so the Android app's "latest"
   release is unaffected); `appRelease()` caches per release.

Secrets:

    APNS_KEY        contents of AuthKey_XXXXXXXXXX.p8 (APNs key, developer.apple.com → Keys)
    APNS_KEY_ID     the 10 characters in that file's name
    APNS_TEAM_ID    the Apple Developer team id
    APNS_BUNDLE_ID  the app's bundle id (APP_ID)
